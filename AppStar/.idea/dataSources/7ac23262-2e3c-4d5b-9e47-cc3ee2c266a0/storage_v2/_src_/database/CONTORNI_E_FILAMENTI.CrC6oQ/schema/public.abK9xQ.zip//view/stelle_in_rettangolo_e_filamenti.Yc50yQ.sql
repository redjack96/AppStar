CREATE VIEW stelle_in_rettangolo_e_filamenti AS
  SELECT DISTINCT stelle."IDSTAR"
   FROM (((punti_contorni p
     JOIN punti_contorni p2 ON (((p2."N" = (p."N" + 1)) AND ((p."SATELLITE")::text = (p2."SATELLITE")::text))))
     JOIN contorni c ON (((p."N" = c."NPCONT") AND ((p."SATELLITE")::text = (c."SATELLITE")::text))))
     JOIN filamenti f ON ((((c."NAME_FIL")::text = (f."NAME")::text) AND ((c."SATELLITE")::text = (f."SATELLITE")::text)))),
    stelle
  WHERE (((f."SATELLITE")::text = 'Herschel'::text) AND ((f."NAME")::text IN ( SELECT filamenti_in_rettangolo."NAME"
           FROM filamenti_in_rettangolo)) AND (stelle."IDSTAR" IN ( SELECT stelle_in_rettangolo."IDSTAR"
           FROM stelle_in_rettangolo)))
  GROUP BY stelle."IDSTAR"
 HAVING (abs(sum(atan((((((p."GLON_CONT" - stelle."GLON_ST") * (p2."GLAT_CONT" - stelle."GLAT_ST")) - ((p."GLAT_CONT" - stelle."GLAT_ST") * (p2."GLON_CONT" - stelle."GLON_ST"))) / (((p."GLON_CONT" - stelle."GLON_ST") * (p2."GLON_CONT" - stelle."GLON_ST")) + ((p."GLAT_CONT" - stelle."GLAT_ST") * (p2."GLAT_CONT" - stelle."GLAT_ST")))))::double precision))) >= (0.01)::double precision);

