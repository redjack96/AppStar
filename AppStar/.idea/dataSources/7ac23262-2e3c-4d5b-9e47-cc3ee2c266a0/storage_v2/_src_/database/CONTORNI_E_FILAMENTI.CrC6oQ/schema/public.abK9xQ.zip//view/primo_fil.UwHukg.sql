CREATE VIEW primo_fil AS
  SELECT punti_contorni."GLON_CONT",
    punti_contorni."GLAT_CONT",
    punti_contorni."N"
   FROM (contorni
     JOIN punti_contorni ON (((contorni."NPCONT" = punti_contorni."N") AND ((contorni."SATELLITE")::text = (punti_contorni."SATELLITE")::text))))
  WHERE ((contorni."NAME_FIL")::text = 'HiGALFil013.9201-1.2385'::text);

