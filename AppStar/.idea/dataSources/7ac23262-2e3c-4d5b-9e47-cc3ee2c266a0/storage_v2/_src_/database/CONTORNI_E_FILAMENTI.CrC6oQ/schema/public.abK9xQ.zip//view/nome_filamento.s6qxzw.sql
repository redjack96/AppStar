CREATE VIEW nome_filamento AS
  SELECT f."NAME"
   FROM filamenti f
  WHERE (((f."SATELLITE")::text = 'Herschel'::text) AND (f."IDFIL" = 45));

