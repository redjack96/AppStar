CREATE VIEW maxn_contorni_imp AS
  SELECT contorni_imp."IDFIL",
    count(contorni_imp."IDFIL") AS count
   FROM contorni_imp
  GROUP BY contorni_imp."IDFIL"
  ORDER BY contorni_imp."IDFIL";

