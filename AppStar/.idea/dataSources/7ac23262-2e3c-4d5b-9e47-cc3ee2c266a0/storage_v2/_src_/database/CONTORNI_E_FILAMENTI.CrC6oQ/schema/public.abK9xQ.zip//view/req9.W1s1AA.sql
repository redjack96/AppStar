CREATE VIEW req9 AS
  SELECT p."GLON_CONT" AS x1,
    p."GLAT_CONT" AS y1,
    p."N" AS n1,
    p2."N" AS n2,
    p2."GLON_CONT" AS x2,
    p2."GLAT_CONT" AS y2,
    c."NAME_FIL" AS nome,
    f."IDFIL" AS idfil
   FROM (((punti_contorni p
     JOIN punti_contorni p2 ON ((p2."N" = (p."N" + 1))))
     JOIN contorni c ON ((p."N" = c."NPCONT")))
     JOIN filamenti f ON (((c."NAME_FIL")::text = (f."NAME")::text)))
  WHERE ((f."IDFIL" = 45) AND ((c."SATELLITE")::text = 'Herschel'::text));

