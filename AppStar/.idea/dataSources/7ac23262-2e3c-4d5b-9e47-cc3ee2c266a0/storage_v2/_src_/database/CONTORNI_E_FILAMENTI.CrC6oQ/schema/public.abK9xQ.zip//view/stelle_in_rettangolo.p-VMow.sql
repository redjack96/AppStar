CREATE VIEW stelle_in_rettangolo AS
  SELECT stelle."IDSTAR"
   FROM stelle
  WHERE ((stelle."GLON_ST" > ('-6'::integer)::numeric) AND (stelle."GLON_ST" < (6)::numeric) AND (stelle."GLAT_ST" > ('-2'::integer)::numeric) AND (stelle."GLAT_ST" < (2)::numeric));

