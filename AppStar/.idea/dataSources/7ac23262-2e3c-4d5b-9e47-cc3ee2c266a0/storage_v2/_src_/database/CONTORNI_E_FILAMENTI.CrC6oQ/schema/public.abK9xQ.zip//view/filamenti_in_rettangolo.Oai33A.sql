CREATE VIEW filamenti_in_rettangolo AS
  SELECT DISTINCT f."NAME"
   FROM ((filamenti f
     JOIN contorni c ON (((f."NAME")::text = (c."NAME_FIL")::text)))
     JOIN punti_contorni p ON (((p."N" = c."NPCONT") AND ((p."SATELLITE")::text = (c."SATELLITE")::text))))
  WHERE (((f."SATELLITE")::text = 'Herschel'::text) AND (p."GLON_CONT" > ('-6'::integer)::numeric) AND (p."GLON_CONT" < (6)::numeric) AND (p."GLAT_CONT" > ('-2'::integer)::numeric) AND (p."GLAT_CONT" < (2)::numeric));

